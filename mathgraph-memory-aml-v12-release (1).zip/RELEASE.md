# MathGraph Memory v12 — release evidence (2026-10-22)

## Warranted in local environment
- `python -m unittest discover -q`: 50 tests pass.
- `python release_smoke.py`: HTTP startup, authenticated Add/Search, indexed candidate retrieval, and user isolation pass.
- Dockerfile copies all Python modules, correcting v11's missing-import defect.

## Explicit limitations
- No image build attempted: Docker binary unavailable in this runtime.
- No live embedding provider used; hybrid mode uses mocked embeddings in tests. Default deployment uses `MEMORY_RANKER=indexed` (FTS5).
- No authentic held-out downstream coding resolution benchmark or official Smoke/Full evaluation.
- No deployment, pinned public GitHub commit, or leaderboard score established by local tests.
- SQLite `/data` must be backed by persistent storage; this package does not provision the disk.
- API uses `X-Api-Key` or bearer credentials; configure `MEMORY_API_KEY` in Render secrets.
- Source metadata trust is bounded to operator-imported snapshots, not autonomous GitHub verification.

## Quick start
```bash
export MEMORY_API_KEY="choose-a-long-random-secret"
export MEMORY_DB=/tmp/memory.sqlite3
export MEMORY_RANKER=indexed
python app.py
```

## Container deployment
Build from this directory. Mount a persistent volume at `/data`, set `MEMORY_API_KEY`, optionally set `PORT=8080`. Do not use ephemeral SQLite for scored runs.

## Next authoritative boundary
Publish this exact source tree to a GitHub repository, pin its commit, deploy with persistent storage, inspect logs, run official AML Smoke, and only then submit Full. No score is claimed.
