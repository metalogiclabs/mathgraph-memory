# MathGraph Memory v11: optional dense retrieval + FTS5

Run all tests: `python -m unittest discover -q`.

`MEMORY_RANKER=hybrid MEMORY_API_KEY=... python app.py` enables RRF hybrid mode, which falls back to lexical candidates if the embedding provider is not configured. The embedding provider must accept an OpenAI-compatible request at `MEMORY_EMBEDDING_URL` with bearer token `MEMORY_EMBEDDING_API_KEY` and return `data[].embedding`. The request model is fixed to `text-embedding-v4`; check the actual permitted endpoint and its API requirements before use. Do **not** substitute a different model in the official open-method track.

Run `python index_embeddings.py --user-id <ID>` separately after `/add` and whenever new memories are ingested; vector indexing is not automatic. Search always remains per-user. Retrieval is a proof of concept and scans indexed vectors for the target user; it is **not** a scalable ANN solution. At million/billion token scale an external vector index, retention policy, ingestion jobs, and batching will be necessary. Search requests with a configured but failing embedding provider currently fail instead of silently pretending semantic results were supplied.

The five new unit tests use deterministic fake embeddings; **no actual embedding provider request, live deployment, official Smoke/Full run or authentic coding-resolution comparison is claimed**. The included source-authority snapshots also remain operator-imported, not live verified proof of correctness.

Known caveat: `/health` is unauthenticated. API key protects `/add` and `/search`; deploy with TLS, a persistent disk, externally stored secrets, and capacity controls. No automatic background ingestion is running. Dense index operations are on-demand only.
